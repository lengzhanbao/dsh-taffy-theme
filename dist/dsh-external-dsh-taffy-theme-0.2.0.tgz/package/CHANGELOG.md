# Changelog

## 0.2.0 — 2026-10-19

### 原生侧栏交互交还 DSH；素材改为可选

- **删除**所有改造 DSH 原生侧栏按钮的规则（尺寸、图标替换、伪元素金饰）。
  三种装饰等级现在只作用于主题自己的层，不再改原生控件的布局、图标与点击区域。
  旧规则用低优先级覆盖去压高优先级旧规则是行不通的，这一版直接删掉源头。
- 设置页「侧栏装饰」改为紧凑三段式控件（40px 高、等宽三列），
  修掉大卡片换行后被拉伸成整行的布局问题。
- 背景、侧栏水印、底部 Q 版改为**看图选择**，三种比例各自匹配（16:9 / 9:16 / 1:1）。
- 新增 `经典花房` / `经典舞台` 两个显式选项；`跟随外观` 沿用用户原有壁纸，
  升级不再强制替换背景。
- 侧栏底板压到 94% 不透明，壁纸里的人物不再透到工作区列表上。
- 新增两组回归测试：`native-controls-untouched`（静态守卫，禁止任何规则改动原生
  侧栏控件）与 `art-selection`（素材解析与回退）。
## 0.1.9 — 2026-09-16

### Whale 式侧栏折叠 + 板内对齐

- 侧栏展开/收起：去掉 `face-pet` 裁切头像，改粉金边框 + 原生 panel SVG
- 「新会话」「设置」板：加高内边距、统一脸图尺寸与锚点，上下金粉条同宽对称
- `build.ps1`：优先用 `typescript/bin/tsc`，避免 Windows 下误用 `tsc.cmd` 导致 host 编译失败

## 0.1.8 — 2026-09-16

### 兼容 DSH 0.1.6-alpha（去掉 `dsh-client-runtime`）

- ClientContext 改从 `@deepseek-ai/cordis` 引入；补 locale / ui-renderer 的 type-only Context merge
- `dsh.client.inject`：去掉已删除的 `@deepseek-ai/dsh-client-runtime`，改依赖 `dsh-client-ui-renderer`
- peerDependencies 收拢为 `>=0.1.0-rc.1 <0.2.0-0`（覆盖 0.1.5 / 0.1.6-alpha）

## 0.1.7 — 2026-09-16

### 粉金金粉装饰 + 侧栏板框

- 输入框 / 侧栏 / 对话框：粉金 SVG 角饰、尘条、蝴蝶结、边缘尘点（不撑大边框）
- 「新会话」「设置」展开态：同款粉金板框 `::after`，暗色下描边与光晕加强
- Hero 标题组下补粉金短尘条；标题同步逻辑保持 DSH 0.1.5+ 空态结构
- `verify:pack`：Windows bsdtar 不支持 `--force-local` 时自动回退，本地 CI 可过

## 0.1.6 — 2026-09-10

### 修复空态大字被官方默认盖回（`探索未至之境`）

- DSH 0.1.5-rc.1 重构空态组件，删了 `headlineText` 类名，标题变成标题组里的裸 span。
  旧选择器 `[class*='headlineText']` 匹配不到，替换逻辑静默跳过，默认大字直接露出。
- `hero-copy.ts` 改认新结构：`[data-phase='hero']` 容器下找第一个纯文本 span，
  且仅当文本命中官方默认（中文/英文）才替换，用户自定义标题不碰。
- `chrome-observer.ts` 同步改监测范围；单测按新版 DOM 重写。

## 0.1.5 — 2026-09-10

### 兼容 DSH 0.1.5-rc.1

- `peerDependencies` 各 `@deepseek-ai/*` 范围追加 `^0.1.5-rc.1`（此前上限 `<0.2.0-0`
  prerelease 线）。主题只用稳定 API（cordis / slots / webServer），无需改代码。

## 0.1.4 — 2026-09-03

### 打包修复（v0.1.3 tarball 缺文件，本地正常但市场包启动失败）

- `package.json` 的 `files` 白名单补上 `lib/boot-taffy.js`：`lib/index.js`
  引用了它，但白名单漏掉导致 `npm pack` 把它排除，DSH 加载时报
  `ERR_MODULE_NOT_FOUND ... boot-taffy.js`。本地开发目录文件齐全所以
  一切正常，只有解包后的 tarball 会炸 —— 这就是"本地行、线上崩"的原因。
- 同理补上 `lib/types/**/*.d.ts`（`exports` 指向的类型定义此前也不在包内）。
- `verify:pack` 新增两道门：扫描包内所有 `.js` 的相对 import 并确认目标
  都在包里；host 探针改为从解包后的 tarball 里 import（以前测的是开发
  目录，永远是绿的）。Windows 下 `tar` 解包的盘符路径问题一并修了。

### 动画与流畅度（与 Raiden 对齐，按玻璃拟态动效规范）

- 持续动画只走合成器：星光层 `background-position` 改 `translate3d` + `opacity`
- 纱幕呼吸 `saturate` 滤镜改 `opacity` 脉冲，全屏重绘降为透明度合成
- 标题浮动 `box-shadow` 逐帧绘制精简为纯 `transform`，静态光环保留在基类
- 标题渐变流光周期 7s → 8.5s（渐变周期不低于 8 秒）
- 发送按钮光晕减弱并放缓 2.8s → 3.4s
- `will-change: transform, opacity` 仅加在星光/标题/发送按钮上，滤镜类动画不加
- `prefers-reduced-motion` 补上星光层；窗口 resize 时星光/纱幕/边框一并暂停

### 工程

- 同步 `lib` 构建产物（`heroHeadline` 配置与新版 asset 版本号此前只进了 `src`）
- 重新生成 `src/client/theme-css.ts` 与 `lib/client.js`

## 0.1.3 — 2026-09-02

### 视觉 / Hero
- 首页大标题文案改为 **关注塔菲喵！关注塔菲谢谢喵！**（原"探索未至之境预览版"）
- 标题粉金渐变：亮色玫瑰金（#c99a27→#b8860b）、暗色亮粉金（#ffb8d6→#ffd060），深浅主题字色分明、白底可读
- 标题左侧图标换成圆形 **塔菲喵大头照**（金边 + 粉描边）
- 纯 CSS 动态特效（尊重 `prefers-reduced-motion`）：
  - 加载时标题与头像轻轻上浮淡入
  - 头像金粉光晕随浮动呼吸
  - 标题粉金渐变缓动流光 + 周期高光扫过
- 标题加 `-webkit-text-stroke` 描边，亮色白底保底可读（`paint-order: stroke fill` 已在）
- 新增个性化：标题文案与头像图片地址可在「塔菲工房 → 个性化」自定义，留空即恢复默认塔菲

### 修复
- 图片 URL 加载：host 侧注册 `/plugins/@dsh-external/dsh-taffy-theme/assets/` 静态路由（DSH 默认只提供 `client.js`）
- Release tarball 补全 `lib/assets/route.js` / `manifest.js` / `trust-fence.js`
- `verify:pack` tarball 静态检查 + 开发树 host import 探针
- `build.ps1` host 编译失败时立即中止；`typecheck` 使用 `tsconfig.host.json`
- 资产路由增加 loopback Host 校验（非 127.0.0.1/localhost 返回 403）

### 性能
- 接通 `data-taffy-low-power`：减动效 / 低内存设备自动关 blur 与动画
- CSS 注入去重、Q 图标预加载缓存、MutationObserver 过滤、metrics stamp 去重
- 启动 `boot veil` 消除闪白；`saveData` 弱网下自动熔断动效
- 流畅度：hero 动效接入低功耗 / 减动效 / 关闭动效开关；标题阴影合并为单层；observer 文案同步 rAF 合帧；设置面板文本输入防抖 300ms，避免逐键全量重同步

### 工程
- 新增 GitHub Actions：verify / test / pack 门禁（CI）
- Q chrome、融合舞台、更安静的侧栏装饰
- 刷新 GitHub 预览图（浅色/深色粉金 hero：`preview/light-v2.webp`、`preview/dark-v2.webp`，cache-bust）
- 新增构建漂移门禁：`verify:static` 比对产物内联源 CSS 与 `src/theme` 当前内容，改样式未重新 build 即报错（含 5 项检查）

---
## 0.1.1 — 2026-08-21

### 修复

- Release 包补全 `lib/config.js`，避免 host 加载失败
- `schemastery` 写入 `dependencies`，pnpm / tarball 安装可解析 Cordis schema
- `install-dev` 改用 `pnpm add link:`，禁止手改 profile `package.json`（防 UTF-8 BOM 导致 DSH 无法启动）
- 深浅色对话字色：浅色更深墨、深色金粉白；修复 `applyThemeTokens` 把浅色字钉死在 body 导致暗色变黑字的问题
- 对话正文增加轻量字光晕，提升壁纸上的可读性

### 新增

- `verify:pack`：发版前检查 tarball 内容与 host 可加载性
- `install:release`：本地 pack → profile 冒烟安装脚本
- 对外安装说明：[docs/install.zh.md](docs/install.zh.md) / [docs/install.en.md](docs/install.en.md)

### 工程

- 测试 70 项；静态 / 资产 / pack / capture 门禁全绿

---

## 0.1.0 — 2026-08-20

- 首次公开发布：粉金亚克力 Web 主题、深浅色舞台立绘、Taffy Agent 预设
- 工程化门禁 P1–P5、left-light 去黑边资产

